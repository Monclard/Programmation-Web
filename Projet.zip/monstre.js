// Classe monstre
function Monstre(posx,posy,vitesse, couleur, tempsAttente)
{
  this.posx=posx;
  this.posy=posy;
  this.tuer=false; //true: met en recherche du centre
  this.couleur = couleur; //1:rouge 
  this.direction=0; //-x: arret  1: haut  2: gauche  3: bas  4: droite  
  this.prochaineDirection=0;
  this.vitesse=vitesse;
  this.tempsPac=0;
  this.tempsAttente=tempsAttente;
  this.animationMonstre=0;
  this.imageMonstre = new Image(); //creation d'une nouvelle image pour les murs
  this.imageMonstre.src = "Images/monstres.png"; //chargement de l'image

  this.TypeIA = function(idIA,px,py,dx,dy)
  {
    var id = 0;
    var distance = (px-dx)*(px-dx)+(py-dy)*(py-dy);
    
    switch(idIA)
    {
      case 0: id=0; break;  //agressif
      case 1: id=1; break;  //passif
      case 3:
        if(distance<10000) //si proche
        {
          id=0;            //agressif
        }
        else               //si loin
        {
          id=1;            //passif
        }
        break;
      case 4:
        if(distance<10000) //si proche
        {
          id=1;            //passif
        }
        else               //si loin
        {
          id=0;            //agressif
        }
        break;
    }
    
    return id;
  }

  this.IA = function(pacx,pacy,idIA)
  {
    var desx;
    var desy;
    var prioriteDir=[0,0,0,0]; //priorite des directions de la plus prioritere a la moins
    var dir=0;
    
    if(this.tuer)
    {
      desx=RESMONSTREX * TAILLECASE;
      desy=RESMONSTREY * TAILLECASE;
    }
    else
    {
      desx=pacx;
      desy=pacy;
    }
    
    ///////////////
    // Recherche des directions en fonction de leur priorite
    if(this.TypeIA(idIA) || this.tuer) //IA de base
    {
      if((this.posx-desx)*(this.posx-desx)<(this.posy-desy)*(this.posy-desy))//si on est plus proche en X qu'en Y
      {
        if(this.posy-desy>0) { prioriteDir[0]=1; prioriteDir[3]=3; }
        else { prioriteDir[0]=3; prioriteDir[3]=1; } //si pac en haut
  
        if(this.posx-desx>0) { prioriteDir[1]=2; prioriteDir[2]=4; }
        else {  prioriteDir[1]=4; prioriteDir[2]=2; } //si pac en gauche
      }
      else    
      {
        if(this.posx-desx>0) { prioriteDir[0]=2; prioriteDir[3]=4; }
        else { prioriteDir[0]=4; prioriteDir[3]=2; } //si pac en gauche
  
        if(this.posy-desy>0) { prioriteDir[1]=1; prioriteDir[2]=3; }
        else { prioriteDir[2]=3; prioriteDir[1]=1; } //si pac en haut
      }  
    }
    else //
    {  
      if((this.posx-desx)*(this.posx-desx)>=(this.posy-desy)*(this.posy-desy))//si on est plus proche en Y qu'en X
      {
        if(this.posy-desy>0) { prioriteDir[0]=1; prioriteDir[3]=3; }
        else { prioriteDir[0]=3; prioriteDir[3]=1; } //si pac en haut
  
        if(this.posx-desx>0) { prioriteDir[1]=2; prioriteDir[2]=4; }
        else {  prioriteDir[1]=4; prioriteDir[2]=2; } //si pac en gauche
      }
      else    
      {
        if(this.posx-desx>0) { prioriteDir[0]=2; prioriteDir[3]=4; }
        else { prioriteDir[0]=4; prioriteDir[3]=2; } //si pac en gauche
  
        if(this.posy-desy>0) { prioriteDir[1]=1; prioriteDir[2]=3; }
        else { prioriteDir[2]=3; prioriteDir[1]=1; } //si pac en haut
      } 
    }    
        
    for(var i= 0, n = prioriteDir.length ; i < n ; i++) //parcours chaque direction
    {
      if(this.tempsPac!=0 && !this.tuer) //si le monstre et vivent et le mode pac active on fait fur les monstres donc on inverse les directions.
      {
         prioriteDir[i]=this.DirectionInverse(prioriteDir[i]);
      }
      
      if(dir==0)// tant que l'on a pas trouver de bonne direction.
      {
        if(this.DirectionInverse(prioriteDir[i])!=this.direction && this.DirectionPossible(prioriteDir[i]))//si ce n'est pas un rebrousement et que la direction est possible
         dir=prioriteDir[i]; 
      }
    }
    
    /*
    if(dir==0) //direction non trouvee -> on tente le rebrousement
    {
      if(this.DirectionPossible(this.DirectionInverse(this.direction)))//si rebrousement possible inon on ne bouge pas.
        dir=this.DirectionInverse(this.direction);
    }   */    
    this.direction = dir;
  }
  
  this.DirectionInverse = function(direction) //obtien la direction inverse
  {
    var inv = 0;
    switch(direction)
    {
      case 1: inv=3; break;
      case 2: inv=4; break;
      case 3: inv=1; break;
      case 4: inv=2; break;
    }
    return inv;
  }
  
  this.Deplacement = function(pacx,pacy) //fait bouger le pacman
  {
    var posCaseX = parseInt(this.posx/TAILLECASE)
    var posCaseY = parseInt(this.posy/TAILLECASE)
    
    if((this.posx== posCaseX*TAILLECASE) && (this.posy== posCaseY*TAILLECASE))
    {
      if(this.posx == RESMONSTREX * TAILLECASE && this.posy == RESMONSTREY * TAILLECASE)
      {
        this.tuer=false;
        this.tempsPac=0;
      }
      
      if(this.tempsAttente>0)
      {
        this.tempsAttente--;
      }
      else
      {
        this.IA(pacx,pacy,this.couleur%4);
      }
      
      if(this.tempsPac>0)
        this.tempsPac--;
    }

    switch(this.direction) //on bouge
    {
      case 1: this.posy-=vitesse; break;  //H
      case 2: this.posx-=vitesse; break;  //G
      case 3: this.posy+=vitesse; break;  //B
      case 4: this.posx+=vitesse; break;  //D
    }
  } 

  this.DirectionPossible = function(direction) //detecte si le mouvement est possible dans la direction
  {
    var possible=false;

    var posCaseX = parseInt(this.posx/TAILLECASE);
    var posCaseY = parseInt(this.posy/TAILLECASE);
        
    if(posCaseX <= -1 && direction == 2) 
    {
      this.posx=TAILLETERRAINX*TAILLECASE;
      possible=true;
    }
    else if(posCaseX > TAILLETERRAINX-1  && direction == 4)
    {
      this.posx=-TAILLECASE;
      possible=true;
    }
    else if(posCaseX<=0 || posCaseX > TAILLETERRAINX-2)
    {
      if(direction == 2 || direction==4) //verification direction bonne
        possible=true;
    }
    else
    {    
      switch(direction)
      {                  //regarde la case apres le deplacement d'un pixel
        case 1: if(terrain[posCaseX][parseInt((this.posy-1)/TAILLECASE)]<4) possible=true; break;  //H
        case 2: if(terrain[parseInt((this.posx-1)/TAILLECASE)][posCaseY]<3) possible=true; break;  //G
        case 3:
          if(this.tuer)
          {          
            if(terrain[posCaseX][parseInt((this.posy+TAILLECASE+1)/TAILLECASE)]<4) possible=true;//les yeux peuvent passer la barriere
          }
          else
          {
            if(terrain[posCaseX][parseInt((this.posy+TAILLECASE+1)/TAILLECASE)]<3) possible=true;
          }
          break;  //B
        case 4:
            if(terrain[parseInt((this.posx+TAILLECASE+1)/TAILLECASE)][posCaseY]<3)
              possible=true;
          break;  //D
      } 
    }
    return possible;
  }

  this.AffichageMonstre = function(context)//affichage du pac par son annimation, de la direction et ses coordonnees
  {  
    if(this.tuer) //afficage yeux
    {
      context.drawImage(this.imageMonstre, 8*TAILLECASE,(this.direction-1)*TAILLECASE,TAILLECASE,TAILLECASE,this.posx,this.posy,TAILLECASE,TAILLECASE);
    }
    else
    { 
      if(this.direction>0) //afficage dinamique
      {      //         recoupage de l'image en fonction de l'animation, de la couleur et de sa direction. Affichage en fonction des coordonnees
        if(this.tempsPac==0)
        {
          context.drawImage(this.imageMonstre, (parseInt(this.animationMonstre)+this.couleur*2)*TAILLECASE,(this.direction-1)*TAILLECASE,TAILLECASE,TAILLECASE,this.posx,this.posy,TAILLECASE,TAILLECASE);    
        }
        else
        {
          context.drawImage(this.imageMonstre, 9*TAILLECASE,(parseInt(this.animationMonstre*2))*TAILLECASE,TAILLECASE,TAILLECASE,this.posx,this.posy,TAILLECASE,TAILLECASE);    
        }
        this.animationMonstre+=0.5;
        if(this.animationMonstre>=2) this.animationMonstre=0;
      }
      else//ne bouge pas
      {
        context.drawImage(this.imageMonstre, (parseInt(this.animationMonstre)+this.couleur*2)*TAILLECASE,TAILLECASE,TAILLECASE,TAILLECASE,this.posx,this.posy,TAILLECASE,TAILLECASE);    
        this.animationMonstre+=0.5;
        if(this.animationMonstre>=2) this.animationMonstre=0;
      }
    }
  } 
}
