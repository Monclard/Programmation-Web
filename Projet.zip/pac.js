// Classe perso

function Perso(posx,posy,vitesse)
{
  this.posx=posx;
  this.posy=posy;
  this.vie=3;
  this.score=0;
  this.direction=-4; //-x: arret  1: haut  2: gauche  3: bas  4: droite  
  this.prochaineDirection=-4;
  this.vitesse=vitesse;
  this.animationpac=3;
  this.imagePac = new Image(); //creation d'une nouvelle image pour les murs
  this.imagePac.src = "Images/pac.png"; //chargement de l'image
  
  
  this.Touche = function(event) //defini la prochaine direction voulu par l'utilisateur
  {
    var touche = String.fromCharCode(event.which);
    switch(touche)
    {
      case 'Z': case '&': this.prochaineDirection=1; break;  //H
      case 'Q': case '%': this.prochaineDirection=2; break;  //G
      case 'S': case '(': this.prochaineDirection=3; break;  //B
      case 'D': case '\'': this.prochaineDirection=4; break;  //D
    } 
  }
  
  this.Deplacement = function() //fait bouger le pacman
  {
    var posCaseX = parseInt(this.posx/TAILLECASE)
    var posCaseY = parseInt(this.posy/TAILLECASE)
    
    if((this.posx== posCaseX*TAILLECASE) && (this.posy== posCaseY*TAILLECASE))
    {
      if(this.DirectionPossible(this.prochaineDirection, posCaseX, posCaseY)) //test la possibilite de changement de direction
        this.direction=this.prochaineDirection;
      
      if(this.DirectionPossible(this.direction, posCaseX, posCaseY)==false)// test la possibolite de deplacement sinon on met une direction d'arret
        this.direction=-4;
      
      if(posCaseX>=0 && posCaseY<TAILLETERRAINX)
      {
        if(terrain[posCaseX][posCaseY]==1) //dot detecter
        {
          this.score+=5;
          terrain[posCaseX][posCaseY]=0; //on enleve le dot
          nbrDot--;
        }

        if(terrain[posCaseX][posCaseY]==2) //pacdot detecter
        {
          this.score+=20;
          terrain[posCaseX][posCaseY]=0; //on enleve le pacdot
          ModePac();//on active le mode pac (invincibilite)
        }
      }
    }

    switch(this.direction) //on bouge
    {
      case 1: this.posy-=vitesse; break;  //H
      case 2: this.posx-=vitesse; break;  //G
      case 3: this.posy+=vitesse; break;  //B
      case 4: this.posx+=vitesse; break;  //D
    }
  } 
  
  this.DirectionPossible = function(direction, posCaseX, posCaseY) //detecte si le mouvement est possible dans la direction
  {
    var possible=false;
    
    if(posCaseX <= -1 && direction == 2) 
    {
      this.posx=TAILLETERRAINX*TAILLECASE;
      possible=true;
    }
    else if(posCaseX > TAILLETERRAINX-1  && direction == 4)
    {
      this.posx=-TAILLECASE;
      possible=true;
    }
    else if(posCaseX<=0 || posCaseX > TAILLETERRAINX-2)
    {
      if(direction == 2 || direction==4) //verification direction bonne
        possible=true;
    }
    else
    {    
      switch(direction)
      {                  //regarde la case apres le deplacement d'un pixel
        case 1: if(terrain[posCaseX][parseInt((this.posy-1)/TAILLECASE)]<3) possible=true; break;  //H
        case 2: if(terrain[parseInt((this.posx-1)/TAILLECASE)][posCaseY]<3) possible=true; break;  //G
        case 3: if(terrain[posCaseX][parseInt((this.posy+TAILLECASE+1)/TAILLECASE)]<3) possible=true; break;  //B
        case 4: if(terrain[parseInt((this.posx+TAILLECASE+1)/TAILLECASE)][posCaseY]<3) possible=true; break;  //D
      } 
    }
    return possible;
  }
  
  this.AffichagePac = function(context)//affichage du pac par son annimation, de la direction et ses coordonnees
  {

    
    if(this.direction>0) //afficage dinamique
    {      //         recoupage de l'image en fonction de l'animation et de sa direction. Affichage en fonction des coordonnees
      context.drawImage(this.imagePac, parseInt(this.animationpac)*TAILLECASE,(this.direction-1)*TAILLECASE,TAILLECASE,TAILLECASE,this.posx,this.posy,TAILLECASE,TAILLECASE);    
      this.animationpac+=0.5;
      if(this.animationpac>=4) this.animationpac=0;
    }
    else  //afficage statique
    {
      context.drawImage(this.imagePac, 2*TAILLECASE,0,TAILLECASE,TAILLECASE,this.posx,this.posy,TAILLECASE,TAILLECASE);
      this.animationpac=3;    
    }
  } 
}
