var TAILLECASE = 26;//constante definisant la taille de chaque case du jeu
var TAILLETERRAINX = 21;
var TAILLETERRAINY = 22;
var VITESSEPERSO = 2;
var POSINITX = 10;
var POSINITY = 16;
var RESMONSTREX =10;
var RESMONSTREY =10;

var tempPac;//temps invincibilite
var context;//objet d'ecriture
var pacman;//perso
var monstres;//liste de monstre
var frequance;//vitesse du jeu
var nbrDot;//nombre de dot a ramasser
var niveau;
var tempPause;

var terrain 

  /*
 0   1  2   3  4   5   6  7   8  9  
10 11 12 13 14 15 16 17
  */
var imageMur;

window.onload = function() //execution a la fin du chargement de la page
{
    var canvas = document.getElementById('canvas'); //recuperation de la zone canvas
    canvas.width  = TAILLETERRAINX * TAILLECASE;
    canvas.height =  (TAILLETERRAINY+1) * TAILLECASE;
    context = canvas.getContext('2d');   //recuperation de l'objet d'ecriture que l'on appelle context
    
    context.font = "18pt Calibri,Geneva,Arial";
    context.fillStyle = "rgb(255,255,255)";
    
    NewGame();
}

////////////////////
///Initialisation///
////////////////////
function NewGame()
{
  imageMur = new Image(); //creation d'une nouvelle image pour les murs
  imageMur.src = "Images/murs.png"; //chargement de l'image
  frequance=42;
  niveau=1;
  pacman = new Perso(TAILLECASE*POSINITX,TAILLECASE*POSINITY,VITESSEPERSO);  
  NewNiveau();
}

function NewNiveau()
{
  frequance -= 4;
  ChargementTerrain();
  cptDot();
  if(typeof intervalID!= 'undefined')
    clearInterval(intervalID);
  Init();
  tempPause=100;
}

function Init()
{
   
  monstres = new Array();
  monstres.push(new Monstre(TAILLECASE*10,TAILLECASE*8,VITESSEPERSO, 0, 0));
  monstres.push(new Monstre(TAILLECASE*10,TAILLECASE*10,VITESSEPERSO, 1, 40));
  monstres.push(new Monstre(TAILLECASE*9,TAILLECASE*10,VITESSEPERSO, 2, 80));
  monstres.push(new Monstre(TAILLECASE*11,TAILLECASE*10,VITESSEPERSO, 3, 130));

  pacman.posx = TAILLECASE*POSINITX;
  pacman.posy = TAILLECASE*POSINITY;
  pacman.direction = -4;

  intervalID = setInterval(Update,frequance);//appel de la fonction 10 fois par seconde
  AffichageTerrain(); //false -> affiche tout
}

function ChargementTerrain()
{
  terrain = [
    [4 ,17,17,17,17,17,17,6 ,0 ,16,0 ,16,0 ,4 ,17,17,17,8 ,17,17,17,6 ],//0
    [16,1 ,2 ,1 ,1 ,1 ,1 ,16,0 ,16,0 ,16,0 ,16,1 ,1 ,2 ,16,1 ,1 ,1 ,16],//1
    [16,1 ,4 ,6 ,1 ,12,1 ,16,0 ,16,0 ,16,0 ,16,1 ,12,1 ,13,1 ,12,1 ,16],//2
    [16,1 ,10,11,1 ,16,1 ,16,0 ,16,0 ,16,0 ,16,1 ,16,1 ,1 ,1 ,16,1 ,16],//3
    [16,1 ,5 ,7 ,1 ,13,1 ,5 ,17,7 ,0 ,5 ,17,7 ,1 ,5 ,17,15,1 ,16,1 ,16],//4
    [16,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,16,1 ,16],//5
    [16,1 ,4 ,6 ,1 ,14,17,8 ,17,15,0 ,14,17,15,1 ,12,1 ,14,17,11,1 ,16],//6
    [16,1 ,10,11,1 ,1 ,1 ,16,0 ,0 ,0 ,0 ,0 ,0 ,1 ,16,1 ,1 ,1 ,16,1 ,16],//7
    [16,1 ,5 ,7 ,1 ,12,1 ,13,0 ,4 ,17,6 ,0 ,12,1 ,13,1 ,12,1 ,13,1 ,16],//8
    [16,1 ,1 ,1 ,1 ,16,1 ,0 ,0 ,13,19,16,0 ,16,1 ,1 ,1 ,16,1 ,1 ,1 ,16],//9
    [10,17,17,15,1 ,10,17,15,0 ,3 ,0 ,16,0 ,10,17,15,1 ,10,17,15,1 ,16],/////10
    [16,1 ,1 ,1 ,1 ,16,1 ,0 ,0 ,12,19,16,0 ,16,1 ,1 ,1 ,16,1 ,1 ,1 ,16],//9
    [16,1 ,4 ,6 ,1 ,13,1 ,12,0 ,5 ,17,7 ,0 ,13,1 ,12,1 ,13,1 ,12,1 ,16],//8
    [16,1 ,10,11,1 ,1 ,1 ,16,0 ,0 ,0 ,0 ,0 ,0 ,1 ,16,1 ,1 ,1 ,16,1 ,16],//7
    [16,1 ,5 ,7 ,1 ,14,17,9 ,17,15,0 ,14,17,15,1 ,13,1 ,14,17,11,1 ,16],//6
    [16,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,1 ,16,1 ,16],//5
    [16,1 ,4 ,6 ,1 ,12,1 ,4 ,17,6 ,0 ,4 ,17,6 ,1 ,4 ,17,15,1 ,16,1 ,16],//4
    [16,1 ,10,11,1 ,16,1 ,16,0 ,16,0 ,16,0 ,16,1 ,16,1 ,1 ,1 ,16,1 ,16],//3
    [16,1 ,5 ,7 ,1 ,13,1 ,16,0 ,16,0 ,16,0 ,16,1 ,13,1 ,12,1 ,13,1 ,16],//2
    [16,1 ,2 ,1 ,1 ,1 ,1 ,16,0 ,16,0 ,16,0 ,16,1 ,1 ,2 ,16,1 ,1 ,1 ,16],//1
    [5 ,17,17,17,17,17,17,7 ,0 ,16,0 ,16,0 ,5 ,17,17,17,9 ,17,17,17,7 ]];//0
}

function cptDot()
{
  nbrDot=0;
  for(var y = 0, l = this.terrain.length ; y < l ; y++) //parcours chaque ligne
  {
    var ligne = this.terrain[y];//recuperation d'une ligne

    for(var x = 0, c = ligne.length ; x < c ; x++) //parcour chaque case d'une ligne
    {
      if(ligne[x]==1)//detection dot
      nbrDot++;
    }
  } 
}
////////////////////
///     Update   ///
////////////////////
function Update()
{  
  if(tempPause==0)
  {
    //update perso
    pacman.Deplacement();
    DeplacementMonstre();
    CollisionMonstre();
    pacman.Deplacement();
    DeplacementMonstre();
    CollisionMonstre();
    //update monstre
    
    if(nbrDot==0)
    {
      NewNiveau();
      niveau++;
    }
  }
  else
    tempPause--;
  //affichage
  AffichageTerrain(); //true -> affiche le sol seulement.
  AffichageMonstre();
  pacman.AffichagePac(context); 
  AffichageText();
}

// Gestion du clavier
window.onkeyup = function(event)
{
  pacman.Touche(event);
  //alert("touche");
}

window.onkeydown = function(event)
{
  pacman.prochaineDirection=pacman.direction;
}

/////////////////////
///     Combat    ///
/////////////////////
function CollisionMonstre()
{
  for(var i = 0, nbr = this.monstres.length ; i < nbr ; i++)
  {
    if(!monstres[i].tuer && Contact(monstres[i]))
    {
      if(monstres[i].tempsPac==0)
      {
        clearInterval(intervalID);
        Init();
        pacman.vie--;
        if(pacman.vie<0)
        {
          NewGame();//gameover
        }
      }
      else
      {
        monstres[i].tuer=true;
        pacman.score+=1500;
      }
    }
  }
}

function Contact(monstre)
{
  var c=false;
  var dx = monstre.posx-pacman.posx;
  var dy = monstre.posy-pacman.posy;
  if(dx*dx+dy*dy<100)
    c=true;
  return c;
}

function ModePac()
{
  for(var i = 0, nbr = this.monstres.length ; i < nbr ; i++)
  {
    monstres[i].tempsPac=50;
  }
}

/////////////////////
///   Affichage   ///
/////////////////////
function AffichageText()
{
  context.clearRect(0, TAILLETERRAINY * TAILLECASE, TAILLETERRAINX * TAILLECASE, TAILLECASE);
  context.fillText("Vie : "+pacman.vie+"\tNiveau : "+niveau+"\tScore : "+pacman.score, 10, (TAILLETERRAINY+1) * TAILLECASE-5)
}

function AffichageTerrain()
{
  for(var y = 0, l = this.terrain.length ; y < l ; y++) //parcours chaque ligne
  {
    var ligne = this.terrain[y];//recuperation d'une ligne
    
    for(var x = 0, c = ligne.length ; x < c ; x++) //parcour chaque case d'une ligne
    {
      AffichageMur(ligne[x],y,x); //appelle de l'affichage d'une case
    }
  } 
}

function AffichageMur(id, caseX, caseY)//affichage d'un tile par son type et ses coordonnees
{
  //recoupage de l'image en fonction de l'id et affichage en fonction des coordonnees
  context.drawImage(imageMur, (id%10)*TAILLECASE,parseInt(id/10)*TAILLECASE,TAILLECASE,TAILLECASE,caseX*TAILLECASE,caseY*TAILLECASE,TAILLECASE,TAILLECASE);
}

function AffichageMonstre()
{
  for(var i = 0, nbr = this.monstres.length ; i < nbr ; i++)
  {
    monstres[i].AffichageMonstre(context);
  }
}

function DeplacementMonstre()
{
  for(var i = 0, nbr = this.monstres.length ; i < nbr ; i++)
  {
    monstres[i].Deplacement(pacman.posx,pacman.posy);
  }
}